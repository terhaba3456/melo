# Casino Royale Web Application

## Overview

This is a full-stack web application for a casino gaming platform built with React (frontend), Express.js (backend), and designed to run on Replit. The application features a modern, animated casino-themed interface with premium gaming aesthetics.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter (lightweight React router)
- **Styling**: Tailwind CSS with custom CSS variables for theming
- **UI Components**: Radix UI primitives with shadcn/ui components
- **Animations**: Framer Motion for smooth animations and transitions
- **State Management**: TanStack Query (React Query) for server state
- **Build Tool**: Vite with React plugin

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Runtime**: Node.js 20
- **Database**: PostgreSQL 16 with Drizzle ORM
- **Development**: Hot reload with tsx
- **Production Build**: esbuild for server bundling

### Key Components

#### Frontend Components
- **Navigation**: Top navigation bar with social media links and branding
- **HeroBanner**: Swiper-based carousel for promotional content
- **CasinoSection**: Grid layout showcasing casino offerings with cards
- **SidebarBanners**: Fixed promotional banners on screen edges
- **PopupBanner**: Timed promotional popup with auto-dismiss
- **FloatingElements**: Animated decorative elements (emojis)

#### Backend Structure
- **Routes**: Centralized route registration in `server/routes.ts`
- **Storage**: Abstracted storage interface with in-memory implementation
- **Schema**: Drizzle ORM schema definitions in `shared/schema.ts`
- **Vite Integration**: Development server with HMR support

## Data Flow

### Database Schema
- **Users Table**: Basic user management with id, username, and password fields
- **Schema Validation**: Zod-based validation with Drizzle integration

### Storage Layer
- **Interface**: `IStorage` defines CRUD operations for data access
- **Implementation**: `MemStorage` provides in-memory storage for development
- **Methods**: User creation, retrieval by ID and username

### API Structure
- **Prefix**: All API routes use `/api` prefix
- **Middleware**: Request logging with duration tracking and JSON response capture
- **Error Handling**: Centralized error middleware with status code handling

## External Dependencies

### Frontend Libraries
- **UI Framework**: React with extensive Radix UI component library
- **Styling**: Tailwind CSS with PostCSS processing
- **Animation**: Framer Motion for interactive animations
- **Carousel**: Swiper.js for image carousels
- **Icons**: Lucide React and React Icons for social media

### Backend Dependencies
- **Database**: Neon serverless PostgreSQL driver
- **ORM**: Drizzle ORM with PostgreSQL dialect
- **Session**: Connect-pg-simple for PostgreSQL session storage
- **Utilities**: Date-fns for date manipulation

### Development Tools
- **Type Checking**: TypeScript with strict configuration
- **Build**: Vite for frontend, esbuild for backend
- **Database**: Drizzle Kit for schema management and migrations

## Deployment Strategy

### Replit Configuration
- **Modules**: Node.js 20, web server, PostgreSQL 16
- **Port**: Application runs on port 5000, exposed as port 80
- **Build Process**: Two-stage build (Vite for frontend, esbuild for backend)
- **Environment**: Autoscale deployment target

### Development Workflow
- **Hot Reload**: Vite dev server with HMR for frontend changes
- **Backend**: tsx for TypeScript execution with file watching
- **Database**: Drizzle push for schema synchronization

### Production Build
- **Frontend**: Static files built to `dist/public`
- **Backend**: Bundled server code in `dist/index.js`
- **Assets**: Vite handles asset optimization and bundling

## Changelog

```
Changelog:
- June 26, 2025. Initial setup
```

## User Preferences

```
Preferred communication style: Simple, everyday language.
```