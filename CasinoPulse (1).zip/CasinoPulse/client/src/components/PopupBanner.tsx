import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X } from "lucide-react";

export default function PopupBanner() {
  const [isVisible, setIsVisible] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsVisible(false);
    }, 10000);

    return () => clearTimeout(timer);
  }, []);

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          className="fixed bottom-4 left-1/2 transform -translate-x-1/2 z-50 w-full max-w-2xl px-4"
          initial={{ opacity: 0, y: 100 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 100 }}
          transition={{ duration: 0.5 }}
        >
          <div className="bg-gradient-to-r from-yellow-400 via-red-500 to-pink-600 rounded-2xl shadow-2xl overflow-hidden animate-pulse-glow">
            <img 
              src="https://images.unsplash.com/photo-1551798507-629020c81463?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=200" 
              alt="Exclusive casino promotional banner" 
              className="absolute inset-0 w-full h-full object-cover opacity-30" 
            />
            <div className="relative z-10 flex items-center justify-between p-4">
              <div className="text-white">
                <h3 className="text-xl font-bold mb-1">🎉 EXCLUSIVE OFFER!</h3>
                <p className="text-sm opacity-90">Get 1000₺ Welcome Bonus + 100 Free Spins</p>
              </div>
              <div className="flex items-center space-x-3">
                <motion.button
                  className="bg-white text-red-600 font-bold py-2 px-6 rounded-full hover:bg-gray-100 transition-colors duration-200"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  CLAIM NOW
                </motion.button>
                <motion.button
                  className="text-white hover:text-gray-300 transition-colors duration-200"
                  onClick={() => setIsVisible(false)}
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <X className="w-6 h-6" />
                </motion.button>
              </div>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
