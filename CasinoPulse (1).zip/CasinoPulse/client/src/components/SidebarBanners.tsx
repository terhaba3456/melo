import { motion } from "framer-motion";

export default function SidebarBanners() {
  return (
    <>
      {/* Left Sidebar Banner */}
      <motion.div
        className="hidden lg:block fixed left-4 top-1/2 transform -translate-y-1/2 z-40"
        initial={{ opacity: 0, x: -100 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.8, delay: 0.5 }}
      >
        <div className="w-32 h-96 bg-gradient-to-b from-purple-600 to-pink-600 rounded-xl shadow-2xl overflow-hidden animate-pulse-glow">
          <img 
            src="https://images.unsplash.com/photo-1596838132731-3301c3fd4317?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=600" 
            alt="Casino promotional banner" 
            className="w-full h-full object-cover opacity-80" 
          />
          <div className="absolute inset-0 bg-gradient-to-t from-purple-900/80 to-transparent flex flex-col justify-end p-4">
            <h3 className="text-white text-sm font-bold mb-2">MEGA BONUS</h3>
            <p className="text-yellow-300 text-xs">Up to 1000₺</p>
          </div>
        </div>
      </motion.div>

      {/* Right Sidebar Banner */}
      <motion.div
        className="hidden lg:block fixed right-4 top-1/2 transform -translate-y-1/2 z-40"
        initial={{ opacity: 0, x: 100 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.8, delay: 0.7 }}
      >
        <div className="w-32 h-96 bg-gradient-to-b from-blue-600 to-green-600 rounded-xl shadow-2xl overflow-hidden animate-pulse-glow">
          <img 
            src="https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=600" 
            alt="Casino chips and cards" 
            className="w-full h-full object-cover opacity-80" 
          />
          <div className="absolute inset-0 bg-gradient-to-t from-blue-900/80 to-transparent flex flex-col justify-end p-4">
            <h3 className="text-white text-sm font-bold mb-2">VIP CLUB</h3>
            <p className="text-yellow-300 text-xs">Exclusive</p>
          </div>
        </div>
      </motion.div>
    </>
  );
}
