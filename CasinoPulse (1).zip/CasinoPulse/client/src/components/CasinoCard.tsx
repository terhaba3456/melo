import { motion } from "framer-motion";
import { Star } from "lucide-react";

interface CasinoCardProps {
  name: string;
  bonus: string;
  description: string;
  image: string;
  borderColor: string;
  glowClass: string;
  buttonColor: string;
  textColor: string;
}

export default function CasinoCard({
  name,
  bonus,
  description,
  image,
  borderColor,
  glowClass,
  buttonColor,
  textColor
}: CasinoCardProps) {
  return (
    <motion.div
      className={`bg-slate-800/50 backdrop-blur-sm rounded-2xl p-6 border-2 ${borderColor} shadow-xl hover:shadow-2xl transition-all duration-300 ${glowClass}`}
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
      initial={{ opacity: 0, y: 50 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
    >
      <div className="mb-4">
        <img 
          src={image} 
          alt={`${name} logo`} 
          className="w-full h-32 object-cover rounded-lg mb-4" 
        />
        <div className="flex justify-center">
          <motion.div
            className={`w-8 h-8 ${textColor}`}
            animate={{ y: [-5, 5, -5] }}
            transition={{ duration: 2, repeat: Infinity }}
          >
            <Star className="w-full h-full fill-current" />
          </motion.div>
        </div>
      </div>
      <div className="text-center">
        <h4 className="text-white font-bold text-lg mb-2">{name}</h4>
        <p className={`${textColor} font-bold text-xl mb-4`}>{bonus}</p>
        <p className="text-gray-300 text-sm mb-6">{description}</p>
        <motion.button
          className={`w-full ${buttonColor} font-bold py-3 px-6 rounded-xl transition-all duration-300`}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          animate={{ 
            boxShadow: [
              "0 0 20px rgba(59, 130, 246, 0.5)",
              "0 0 30px rgba(59, 130, 246, 0.8)",
              "0 0 20px rgba(59, 130, 246, 0.5)"
            ]
          }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          GIRIS YAP
        </motion.button>
      </div>
    </motion.div>
  );
}
