import { motion } from "framer-motion";
import CasinoCard from "./CasinoCard";

export default function CasinoSection() {
  const mainSponsors = [
    {
      name: "SPIN CASINO",
      bonus: "300% DENEME BONUSU",
      description: "Up to 1000₺ Welcome Bonus",
      image: "https://images.unsplash.com/photo-1606092195730-5d7b9af1efc5?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=60",
      borderColor: "border-green-500",
      glowClass: "glow-green",
      buttonColor: "bg-green-500 hover:bg-green-400 text-white",
      textColor: "text-green-400"
    },
    {
      name: "OTOBET",
      bonus: "100% DENEME BONUSU",
      description: "Sports Betting & Casino",
      image: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=60",
      borderColor: "border-orange-500",
      glowClass: "glow-orange",
      buttonColor: "bg-orange-500 hover:bg-orange-400 text-white",
      textColor: "text-orange-400"
    },
    {
      name: "MAXWIN",
      bonus: "500₺ DENEME BONUSU",
      description: "Premium Gaming Experience",
      image: "https://images.unsplash.com/photo-1596838132731-3301c3fd4317?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=60",
      borderColor: "border-blue-500",
      glowClass: "glow-blue",
      buttonColor: "bg-blue-500 hover:bg-blue-400 text-white",
      textColor: "text-blue-400"
    }
  ];

  const vipSponsors = [
    {
      name: "RAMADABET",
      bonus: "200₺ DENEME BONUSU",
      description: "VIP Gaming Experience",
      image: "https://images.unsplash.com/photo-1551798507-629020c81463?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=60",
      borderColor: "border-purple-500",
      glowClass: "glow-purple",
      buttonColor: "bg-purple-500 hover:bg-purple-400 text-white",
      textColor: "text-purple-400"
    },
    {
      name: "SUPERBET",
      bonus: "150₺ DENEME BONUSU",
      description: "Super Gaming Platform",
      image: "https://images.unsplash.com/photo-1611003228941-98852ba62227?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=60",
      borderColor: "border-red-500",
      glowClass: "glow-red",
      buttonColor: "bg-red-500 hover:bg-red-400 text-white",
      textColor: "text-red-400"
    },
    {
      name: "500 CASINO",
      bonus: "500₺ BONUSLARLI",
      description: "Premium Slots & Games",
      image: "https://images.unsplash.com/photo-1606092195730-5d7b9af1efc5?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=60",
      borderColor: "border-yellow-500",
      glowClass: "glow-yellow",
      buttonColor: "bg-yellow-500 hover:bg-yellow-400 text-black",
      textColor: "text-yellow-400"
    },
    {
      name: "REKLAM",
      bonus: "İLETİŞİM GEÇİNİZ",
      description: "Advertising Space",
      image: "https://images.unsplash.com/photo-1551798507-629020c81463?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=60",
      borderColor: "border-teal-500",
      glowClass: "glow-teal",
      buttonColor: "bg-teal-500 hover:bg-teal-400 text-white",
      textColor: "text-teal-400"
    }
  ];

  const regularSponsors = [
    {
      name: "CASINOROYS",
      bonus: "25₺ FREESPİN BONUSU",
      description: "Free Spins Galore",
      image: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=60",
      borderColor: "border-cyan-500",
      glowClass: "glow-cyan",
      buttonColor: "bg-cyan-500 hover:bg-cyan-400 text-white",
      textColor: "text-cyan-400"
    },
    {
      name: "LIGOBET",
      bonus: "100₺ BONUSLU LIGABET",
      description: "Sports & Casino",
      image: "https://images.unsplash.com/photo-1551798507-629020c81463?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=60",
      borderColor: "border-emerald-500",
      glowClass: "glow-emerald",
      buttonColor: "bg-emerald-500 hover:bg-emerald-400 text-white",
      textColor: "text-emerald-400"
    },
    {
      name: "SPINCO",
      bonus: "500₺ DENEME BONUSU",
      description: "Spin & Win Big",
      image: "https://images.unsplash.com/photo-1596838132731-3301c3fd4317?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=60",
      borderColor: "border-pink-500",
      glowClass: "glow-pink",
      buttonColor: "bg-pink-500 hover:bg-pink-400 text-white",
      textColor: "text-pink-400"
    },
    {
      name: "GATABET",
      bonus: "GAİBET BAHIS",
      description: "Premium Betting",
      image: "https://images.unsplash.com/photo-1611003228941-98852ba62227?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=60",
      borderColor: "border-indigo-500",
      glowClass: "glow-indigo",
      buttonColor: "bg-indigo-500 hover:bg-indigo-400 text-white",
      textColor: "text-indigo-400"
    },
    {
      name: "GOLD CASINO",
      bonus: "750₺ WELCOME BONUS",
      description: "Luxury Gaming",
      image: "https://images.unsplash.com/photo-1606092195730-5d7b9af1efc5?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=60",
      borderColor: "border-amber-500",
      glowClass: "glow-amber",
      buttonColor: "bg-amber-500 hover:bg-amber-400 text-black",
      textColor: "text-amber-400"
    }
  ];

  return (
    <div className="space-y-12">
      {/* Main Sponsors */}
      <section>
        <motion.div
          className="flex items-center justify-center mb-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <div className="bg-gradient-to-r from-yellow-400 to-orange-500 px-6 py-3 rounded-full">
            <h3 className="text-xl font-bold text-black">⭐ MAIN SPONSORS</h3>
          </div>
        </motion.div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {mainSponsors.map((casino, index) => (
            <motion.div
              key={casino.name}
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
            >
              <CasinoCard {...casino} />
            </motion.div>
          ))}
        </div>
      </section>

      {/* VIP Sponsors */}
      <section>
        <motion.div
          className="flex items-center justify-center mb-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
        >
          <div className="bg-gradient-to-r from-purple-500 to-pink-500 px-6 py-3 rounded-full">
            <h3 className="text-xl font-bold text-white">💎 VIP SPONSORS</h3>
          </div>
        </motion.div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {vipSponsors.map((casino, index) => (
            <motion.div
              key={casino.name}
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
            >
              <CasinoCard {...casino} />
            </motion.div>
          ))}
        </div>
      </section>

      {/* Regular Sponsors */}
      <section>
        <motion.div
          className="flex items-center justify-center mb-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.6 }}
        >
          <div className="bg-gradient-to-r from-blue-500 to-cyan-500 px-6 py-3 rounded-full">
            <h3 className="text-xl font-bold text-white">🎲 REGULAR SPONSORS</h3>
          </div>
        </motion.div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
          {regularSponsors.map((casino, index) => (
            <motion.div
              key={casino.name}
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
            >
              <CasinoCard {...casino} />
            </motion.div>
          ))}
        </div>
      </section>
    </div>
  );
}
