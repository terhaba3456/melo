import { FaSkype, FaTelegram, FaWhatsapp } from "react-icons/fa";
import { motion } from "framer-motion";

export default function Navigation() {
  return (
    <nav className="relative z-50 bg-slate-800/80 backdrop-blur-sm border-b border-purple-500/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Social Icons Left */}
          <div className="flex items-center space-x-4">
            <motion.a
              href="#"
              className="bg-blue-600 hover:bg-blue-500 p-2 rounded-lg transition-colors duration-200"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.95 }}
            >
              <FaSkype className="w-5 h-5 text-white" />
            </motion.a>
            <motion.a
              href="#"
              className="bg-blue-500 hover:bg-blue-400 p-2 rounded-lg transition-colors duration-200"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.95 }}
            >
              <FaTelegram className="w-5 h-5 text-white" />
            </motion.a>
          </div>

          {/* Centered Logo */}
          <div className="flex-1 flex justify-center">
            <motion.div
              className="flex items-center space-x-3"
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <div className="w-10 h-10 bg-gradient-to-r from-pink-500 to-purple-600 rounded-lg flex items-center justify-center">
                <svg className="w-6 h-6 text-white" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
                </svg>
              </div>
              <h1 className="text-2xl font-bold text-white">
                Casino<span className="text-pink-400">Royale</span>
              </h1>
            </motion.div>
          </div>

          {/* Social Icons Right */}
          <div className="flex items-center space-x-4">
            <motion.a
              href="#"
              className="bg-green-600 hover:bg-green-500 p-2 rounded-lg transition-colors duration-200"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.95 }}
            >
              <FaWhatsapp className="w-5 h-5 text-white" />
            </motion.a>
            <motion.a
              href="#"
              className="bg-blue-400 hover:bg-blue-300 p-2 rounded-lg transition-colors duration-200"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.95 }}
            >
              <FaTelegram className="w-5 h-5 text-white" />
            </motion.a>
          </div>
        </div>
      </div>
    </nav>
  );
}
