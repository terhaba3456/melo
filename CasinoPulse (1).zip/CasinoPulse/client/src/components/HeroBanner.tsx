import { useEffect, useRef } from "react";
import { motion } from "framer-motion";

export default function HeroBanner() {
  const swiperRef = useRef<any>(null);

  useEffect(() => {
    if (typeof window !== "undefined" && window.Swiper) {
      swiperRef.current = new window.Swiper('.mainSlider', {
        loop: true,
        autoplay: {
          delay: 5000,
          disableOnInteraction: false,
        },
        pagination: {
          el: '.swiper-pagination',
          clickable: true,
        },
        navigation: {
          nextEl: '.swiper-button-next',
          prevEl: '.swiper-button-prev',
        },
        effect: 'fade',
        fadeEffect: {
          crossFade: true
        }
      });
    }

    return () => {
      if (swiperRef.current) {
        swiperRef.current.destroy();
      }
    };
  }, []);

  return (
    <div className="relative mb-12">
      <div className="swiper mainSlider">
        <div className="swiper-wrapper">
          {/* Slide 1 */}
          <div className="swiper-slide">
            <div className="relative h-80 bg-gradient-to-r from-purple-600 via-pink-600 to-red-600 rounded-2xl overflow-hidden shadow-2xl">
              <img 
                src="https://images.unsplash.com/photo-1551798507-629020c81463?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&h=600" 
                alt="Glamorous casino setting" 
                className="absolute inset-0 w-full h-full object-cover opacity-40" 
              />
              <div className="absolute inset-0 bg-gradient-to-r from-purple-900/60 to-pink-900/60"></div>
              <div className="relative z-10 h-full flex items-center justify-between px-8">
                <motion.div
                  className="text-white"
                  initial={{ opacity: 0, x: -50 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.8 }}
                >
                  <h2 className="text-5xl font-bold mb-4">500₺</h2>
                  <p className="text-2xl font-semibold mb-2">FREEBET BONUS</p>
                  <p className="text-lg opacity-90">Welcome to the ultimate gaming experience!</p>
                  <motion.button
                    className="mt-6 bg-yellow-500 hover:bg-yellow-400 text-black font-bold py-3 px-8 rounded-full transition-all duration-300"
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    animate={{ 
                      boxShadow: [
                        "0 0 20px rgba(234, 179, 8, 0.5)",
                        "0 0 40px rgba(234, 179, 8, 0.8)",
                        "0 0 20px rgba(234, 179, 8, 0.5)"
                      ]
                    }}
                    transition={{ duration: 2, repeat: Infinity }}
                  >
                    CLAIM NOW
                  </motion.button>
                </motion.div>
                <motion.div
                  className="hidden md:block"
                  animate={{ y: [-10, 10, -10] }}
                  transition={{ duration: 3, repeat: Infinity }}
                >
                  <div className="w-32 h-32 bg-yellow-400 rounded-full flex items-center justify-center shadow-lg">
                    <span className="text-3xl">🍭</span>
                  </div>
                </motion.div>
              </div>
            </div>
          </div>
          
          {/* Slide 2 */}
          <div className="swiper-slide">
            <div className="relative h-80 bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 rounded-2xl overflow-hidden shadow-2xl">
              <img 
                src="https://images.unsplash.com/photo-1611003228941-98852ba62227?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&h=600" 
                alt="Casino roulette wheel with chips" 
                className="absolute inset-0 w-full h-full object-cover opacity-40" 
              />
              <div className="absolute inset-0 bg-gradient-to-r from-blue-900/60 to-purple-900/60"></div>
              <div className="relative z-10 h-full flex items-center justify-between px-8">
                <motion.div
                  className="text-white"
                  initial={{ opacity: 0, x: -50 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.8 }}
                >
                  <h2 className="text-5xl font-bold mb-4">500</h2>
                  <p className="text-2xl font-semibold mb-2">FREE SPINS</p>
                  <p className="text-lg opacity-90">Spin your way to massive wins!</p>
                  <motion.button
                    className="mt-6 bg-green-500 hover:bg-green-400 text-white font-bold py-3 px-8 rounded-full transition-all duration-300"
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    animate={{ 
                      boxShadow: [
                        "0 0 20px rgba(34, 197, 94, 0.5)",
                        "0 0 40px rgba(34, 197, 94, 0.8)",
                        "0 0 20px rgba(34, 197, 94, 0.5)"
                      ]
                    }}
                    transition={{ duration: 2, repeat: Infinity }}
                  >
                    SPIN NOW
                  </motion.button>
                </motion.div>
                <motion.div
                  className="hidden md:block"
                  animate={{ y: [-10, 10, -10] }}
                  transition={{ duration: 3, repeat: Infinity }}
                >
                  <div className="w-32 h-32 bg-green-400 rounded-full flex items-center justify-center shadow-lg">
                    <span className="text-3xl">🎰</span>
                  </div>
                </motion.div>
              </div>
            </div>
          </div>
        </div>
        <div className="swiper-pagination"></div>
        <div className="swiper-button-next"></div>
        <div className="swiper-button-prev"></div>
      </div>
    </div>
  );
}
