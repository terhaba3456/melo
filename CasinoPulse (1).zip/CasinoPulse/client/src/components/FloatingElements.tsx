import { motion } from "framer-motion";

export default function FloatingElements() {
  const elements = [
    { emoji: "💎", top: "20%", left: "10%", delay: 0 },
    { emoji: "🎰", top: "40%", right: "20%", delay: 1 },
    { emoji: "🍀", bottom: "40%", left: "20%", delay: 2 },
    { emoji: "⭐", top: "60%", left: "50%", delay: 1.5 },
    { emoji: "🎲", bottom: "60%", right: "10%", delay: 0.5 }
  ];

  return (
    <div className="fixed inset-0 pointer-events-none z-10 overflow-hidden">
      {elements.map((element, index) => (
        <motion.div
          key={index}
          className="absolute text-4xl"
          style={{
            top: element.top,
            bottom: element.bottom,
            left: element.left,
            right: element.right
          }}
          animate={{
            y: [-10, 10, -10],
            rotate: [0, 5, -5, 0],
            opacity: [0.6, 1, 0.6]
          }}
          transition={{
            duration: 3,
            repeat: Infinity,
            delay: element.delay
          }}
        >
          {element.emoji}
        </motion.div>
      ))}
    </div>
  );
}
