import Navigation from "@/components/Navigation";
import HeroBanner from "@/components/HeroBanner";
import SidebarBanners from "@/components/SidebarBanners";
import CasinoSection from "@/components/CasinoSection";
import PopupBanner from "@/components/PopupBanner";
import FloatingElements from "@/components/FloatingElements";

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      <Navigation />
      <SidebarBanners />
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <HeroBanner />
        <CasinoSection />
      </div>
      <PopupBanner />
      <FloatingElements />
    </div>
  );
}
